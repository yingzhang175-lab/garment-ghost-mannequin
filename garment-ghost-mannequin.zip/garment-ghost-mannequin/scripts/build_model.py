"""Build an approximate textured wardrobe GLB from registered transparent orthographic views."""
import argparse
import base64
import io
import json
import struct
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter
from surface import surface

# +Z faces the camera for the front view. Left/right refer to the wearer.
CAMERAS = {
    "front": (0, 0, 1), "back": (0, 0, -1),
    "left": (1, 0, 0), "right": (-1, 0, 0),
}


class View:
    def __init__(self, name, path):
        with Image.open(path) as source:
            rgba = source.convert("RGBA")
        alpha = rgba.getchannel("A")
        if alpha.getextrema()[0] != 0:
            raise ValueError(f"{name} 输入缺少透明背景。")
        bounds = alpha.point(lambda v: 255 if v >= 32 else 0).getbbox()
        if not bounds:
            raise ValueError(f"{name} 没有可用的衣物轮廓。")
        self.image = rgba.crop(bounds)
        self.aspect = self.image.width / self.image.height
        self.name = name
        self.direction = np.array(CAMERAS[name])
        self.across = np.cross([0, 1, 0], self.direction)
        mask = self.image.getchannel("A")
        mask.thumbnail((450, 450), Image.Resampling.LANCZOS)
        self.mask = np.asarray(mask.filter(ImageFilter.GaussianBlur(0.7))) / 255
        self.mask_height, self.mask_width = self.mask.shape

    def uv(self, xyz):
        return np.stack([0.5 + xyz @ self.across / self.aspect, 1 - xyz[:, 1]], axis=1)

    def coverage(self, x, y, z):
        u = 0.5 + (self.across[0]*x + self.across[2]*z) / self.aspect
        v = 1 - y
        ix = np.clip((u * self.mask_width).astype(int), 0, self.mask_width - 1)
        iy = np.clip((v * self.mask_height).astype(int), 0, self.mask_height - 1)
        return np.where((u >= 0) & (u <= 1) & (v >= 0) & (v <= 1), self.mask[iy, ix], 0)


def reconstruct(views):
    width = max(v.aspect for v in views if v.name in ("front", "back"))
    depth = max(v.aspect for v in views if v.name in ("left", "right"))
    step = max(1, width, depth) / 144
    bounds = [(-width/2, width/2), (0, 1), (-depth/2, depth/2)]
    axes = [np.arange(lo-3*step, hi+4*step, step) for lo, hi in bounds]
    x, y, z = np.ix_(*axes)
    # Intersect silhouettes (including interior gaps). Round the otherwise boxy
    # four-view hull using each row's own centres and radii.
    masks = [v.coverage(x, y, z) for v in views]
    field = np.minimum.reduce(masks).astype(np.float32) - 0.5
    occupied = field > 0
    horizontal = occupied.any(axis=2)
    lateral = occupied.any(axis=0).T
    def extent(rows, coords):
        low = coords[rows.argmax(axis=0)]
        high = coords[len(coords)-1-rows[::-1].argmax(axis=0)]
        return (low+high)/2, np.maximum((high-low)/2 + step, step)
    cx, rx = extent(horizontal, axes[0])
    cz, rz = extent(lateral, axes[2])
    roundness = 1 - ((x-cx[None,:,None])/rx[None,:,None])**2 - ((z-cz[None,:,None])/rz[None,:,None])**2
    field = np.minimum(field, roundness * 3)
    occupied = field > 0
    fits = {}
    for v, mask in zip(views, masks):
        axis = 2 if v.name in ("front","back") else 0
        expected = (mask > 0.5).any(axis=axis)
        actual = occupied.any(axis=axis)
        fits[v.name] = round(float((expected & actual).sum() / max(1, (expected | actual).sum())), 3)
    if min(fits.values()) < 0.70:
        raise ValueError(f"轮廓对齐不足 {fits}。请核实是否同款同姿态，调整对齐或保留已确认的多视图。")
    return (*surface(field, np.array([a[0] for a in axes]), step), fits)


class GLB:
    def __init__(self):
        self.blob = bytearray()
        self.views, self.accessors = [], []

    def add_bytes(self, data, target=None):
        self.blob.extend(b'\0' * (-len(self.blob) % 4))
        entry = dict(buffer=0, byteOffset=len(self.blob), byteLength=len(data))
        if target:
            entry["target"] = target
        self.views.append(entry)
        self.blob.extend(data)
        return len(self.views)-1

    def attribute(self, array, kind, index=False, bounds=False):
        array = np.ascontiguousarray(array, dtype='<u4' if index else '<f4')
        view = self.add_bytes(array.tobytes(), 34963 if index else 34962)
        spec = dict(bufferView=view, componentType=5125 if index else 5126, count=len(array), type=kind)
        if bounds:
            spec.update(min=array.min(axis=0).tolist(), max=array.max(axis=0).tolist())
        self.accessors.append(spec)
        return len(self.accessors)-1

    def pack(self, doc):
        doc.update(buffers=[dict(byteLength=len(self.blob))], bufferViews=self.views, accessors=self.accessors)
        meta = json.dumps(doc, ensure_ascii=False, separators=(',', ':')).encode()
        meta += b' ' * (-len(meta) % 4)
        binary = self.blob + b'\0' * (-len(self.blob) % 4)
        return (struct.pack('<4sII', b'glTF', 2, 28+len(meta)+len(binary)) +
                struct.pack('<I4s', len(meta), b'JSON') + meta +
                struct.pack('<I4s', len(binary), b'BIN\0') + binary)


def build(views):
    verts, normals, faces, fits = reconstruct(views)
    # Choose a camera by surface direction, including unavailable cameras.
    # Their faces get plain fabric, never a mirrored decoration.
    directions = np.asarray(list(CAMERAS.values()))
    weights = normals[faces].mean(axis=1) @ directions.T
    assignment = weights.argmax(axis=1)
    available = {v.name: v for v in views}
    groups = {v.name: [] for v in views}
    groups["unobserved"] = []
    for i, name in enumerate(CAMERAS):
        groups[name if name in available else "unobserved"].extend(np.flatnonzero(assignment == i))
    front = np.asarray(available['front'].image)
    opaque = front[..., 3] >= 160
    if not opaque.any():
        opaque = front[..., 3] >= 32
    color = tuple(np.median(front[..., :3][opaque], axis=0).astype(int))
    glb = GLB()
    primitives, materials, images, textures = [], [], [], []
    for name, group in groups.items():
        if not len(group):
            continue
        used, mapped = np.unique(faces[group], return_inverse=True)
        attrs = dict(POSITION=glb.attribute(verts[used], 'VEC3', bounds=True), NORMAL=glb.attribute(normals[used], 'VEC3'))
        pbr = dict(metallicFactor=0, roughnessFactor=1)
        if name in available:
            view = available[name]
            attrs['TEXCOORD_0'] = glb.attribute(np.clip(view.uv(verts[used]),0,1), 'VEC2')
            texture = Image.new("RGB", view.image.size, color)
            texture.paste(view.image, mask=view.image.getchannel("A"))
            texture.thumbnail((1536,1536), Image.Resampling.LANCZOS)
            encoded = io.BytesIO()
            texture.save(encoded, format='PNG')
            images.append(dict(mimeType='image/png', bufferView=glb.add_bytes(encoded.getvalue())))
            textures.append(dict(source=len(images)-1, sampler=0))
            pbr['baseColorTexture'] = dict(index=len(textures)-1)
        else:
            # glTF baseColorFactor uses linear RGB.
            srgb = np.asarray(color) / 255
            pbr['baseColorFactor'] = [*np.where(srgb<=0.04045,srgb/12.92,((srgb+0.055)/1.055)**2.4).tolist(),1]
        materials.append(dict(name=name, doubleSided=True, pbrMetallicRoughness=pbr))
        primitives.append(dict(attributes=attrs, indices=glb.attribute(mapped.ravel(), 'SCALAR', index=True), material=len(materials)-1))
    doc = dict(asset=dict(version='2.0', generator='garment-ghost-mannequin'),
               scene=0, scenes=[dict(nodes=[0])], nodes=[dict(mesh=0)], meshes=[dict(primitives=primitives)],
               images=images, textures=textures, samplers=[dict(wrapS=33071,wrapT=33071)],
               materials=materials, extras=dict(method='approximate silhouette hull', observedViews=list(available),
                   missingViews=[n for n in CAMERAS if n not in available], silhouetteIoU=fits, scale='normalized height'))
    return glb.pack(doc), fits


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in CAMERAS:
        parser.add_argument('--'+name, type=Path, required=name in ('front','back'))
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--preview', type=Path)
    args = parser.parse_args()
    if not (args.left or args.right):
        parser.error('需要至少一个已确认方向的侧面。')
    if args.out.exists() or (args.preview and args.preview.exists()):
        parser.error('请用新的输出文件名。')
    if args.preview and args.out.resolve() == args.preview.resolve():
        parser.error('预览和模型须分别保存。')
    try:
        data, fits = build([View(k, getattr(args,k)) for k in CAMERAS if getattr(args,k)])
        html = None
        if args.preview:
            template = Path(__file__).resolve().parents[1] / 'assets' / 'preview.html'
            html = template.read_text().replace('__GLB__', base64.b64encode(data).decode())
        with args.out.open('xb') as f:
            f.write(data)
        if html:
            with args.preview.open('x', encoding='utf8') as f:
                f.write(html)
    except (OSError, ValueError) as error:
        parser.exit(1, str(error)+'\n')
    print(f'各面轮廓重合度 {fits}')


if __name__ == '__main__':
    main()
