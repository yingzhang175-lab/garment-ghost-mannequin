"""Extract a triangle mesh from the zero level of a padded 3D field (surface nets)."""
from itertools import product

import numpy as np


def surface(field, origin, spacing):
    shape = tuple(n - 1 for n in field.shape)
    offsets = list(product((0, 1), repeat=3))
    corners = {p: field[tuple(slice(k, k + n) for k, n in zip(p, shape))] for p in offsets}
    mixed = (np.maximum.reduce(list(corners.values())) > 0) & (np.minimum.reduce(list(corners.values())) <= 0)
    cells = np.argwhere(mixed)
    if not cells.size:
        raise ValueError("轮廓没有形成共有体积，请核对视角和姿态。")
    ids = np.full(shape, -1, np.int32)
    ids[mixed] = np.arange(len(cells))
    hits = np.zeros(len(cells))
    positions = np.zeros_like(cells, dtype=float)
    vals = {p: v[mixed] for p, v in corners.items()}
    faces = []
    axes = np.eye(3, dtype=int)
    for axis, direction in enumerate(axes):
        for p in offsets:
            if p[axis]:
                continue
            v0, v1 = vals[p], vals[tuple(direction + p)]
            crosses = (v0 > 0) != (v1 > 0)
            t = v0[crosses] / (v0[crosses] - v1[crosses])
            positions[crosses] += p + t[:, None] * direction
            hits[crosses] += 1
        inside = field > 0
        edges = np.argwhere(np.diff(inside, axis=axis))
        a, b = axes[(axis + 1) % 3], axes[(axis + 2) % 3]
        quads = np.stack([ids[tuple((edges - d).T)] for d in (a + b, b, np.zeros(3, int), a)], axis=1)
        reverse = ~inside[tuple(edges.T)]
        quads[reverse] = quads[reverse, ::-1]
        faces.extend((quads[:, [0, 1, 2]], quads[:, [0, 2, 3]]))
    vertices = origin + (cells + positions / hits[:, None]) * spacing
    faces = np.concatenate(faces)
    triangles = vertices[faces]
    face_normals = np.cross(triangles[:, 1] - triangles[:, 0], triangles[:, 2] - triangles[:, 0])
    valid = np.linalg.norm(face_normals, axis=1) > 1e-12
    faces, face_normals = faces[valid], face_normals[valid]
    normals = np.zeros_like(vertices)
    for col in faces.T:
        np.add.at(normals, col, face_normals)
    normals /= np.maximum(1e-12, np.linalg.norm(normals, axis=1, keepdims=True))
    return vertices, normals, faces
