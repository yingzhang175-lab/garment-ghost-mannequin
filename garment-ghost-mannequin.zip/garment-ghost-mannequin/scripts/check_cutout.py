"""Check a wardrobe PNG's transparency and report its padding in pixels."""

import argparse

from PIL import Image


def check_cutout(path):
    with Image.open(path) as image:
        if image.format != "PNG":
            raise ValueError("请使用 PNG 文件。")
        alpha = image.convert("RGBA").getchannel("A")
        low, high = alpha.getextrema()
        if low != 0 or high == 0:
            raise ValueError("图片须同时含有完全透明的背景和可见衣物。")
        left, top, right, bottom = alpha.getbbox()
        margins = (left, top, image.width - right, image.height - bottom)
        if min(margins) == 0:
            raise ValueError("可见像素已碰到画布边缘，请检查是否裁到了衣物或有残留背景。")
        return image.size, margins


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("png")
    args = parser.parse_args()
    try:
        size, margins = check_cutout(args.png)
    except (OSError, ValueError) as error:
        parser.exit(1, f"{error}\n")
    print(f"画布 {size[0]} × {size[1]}，透明留边（左、上、右、下）{margins} px")
