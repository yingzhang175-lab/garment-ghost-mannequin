"""Sample a video for inspection or export full-size frames at selected time points."""
import argparse
import csv
import math
from pathlib import Path
import re
import shutil
import subprocess
import sys


def executable():
    command = shutil.which("ffmpeg")
    if command:
        return command
    # Optional local install keeps video decoding available without a global ffmpeg.
    local_runtime = Path(__file__).resolve().parents[1] / ".runtime"
    if local_runtime.is_dir():
        sys.path.insert(0, str(local_runtime))
    try:
        from imageio_ffmpeg import get_ffmpeg_exe
        return get_ffmpeg_exe()
    except (ImportError, RuntimeError) as exc:
        raise ValueError("需要本地 FFmpeg，或安装 Python 包 imageio-ffmpeg。") from exc


def seconds(text):
    value = float(text)
    if not math.isfinite(value) or value < 0:
        raise ValueError("时间参数须为非负有限秒数")
    return value


def extract(args):
    cmd = executable()
    filters = ["setpts=PTS-STARTPTS"]
    targets = []
    if args.at:
        targets = sorted({seconds(v) for v in args.at.split(",")})
        crossings = [f"lt(if(isnan(prev_t),-1,prev_t),{t})*gte(t,{t})" for t in targets]
        select = "+".join(crossings)
    else:
        if args.step <= 0:
            raise ValueError("采样间隔须大于零")
        if args.interval:
            start, end = [seconds(v) for v in args.interval.split(",")]
            if start >= end:
                raise ValueError("起始时间须早于结束时间")
            filters.append(f"trim=start={start}:end={end}")
        select = f"isnan(prev_selected_t)+gte(t-prev_selected_t,{args.step})+gt(scene,0.24)"
    filters.append(f"select='{select}'")
    if not targets:
        filters.append("scale=640:640:force_original_aspect_ratio=decrease:force_divisible_by=2")
    filters.append("showinfo")
    args.output.mkdir(parents=True, exist_ok=False)
    run = [cmd,"-hide_banner","-nostdin","-nostats","-i",str(args.video),"-map","0:v:0","-an",
           "-vf",",".join(filters),"-fps_mode","vfr","-q:v","2",str(args.output/"%06d.jpg")]
    pattern = re.compile(r"Parsed_showinfo.*?\bn:\s*(\d+)\s+pts:\s*-?\d+\s+pts_time:([+\-\d.eE]+)")
    timestamps, tail = [], []
    with subprocess.Popen(run, stderr=subprocess.PIPE, stdout=subprocess.DEVNULL, text=True, errors="replace") as proc:
        for line in proc.stderr:
            match = pattern.search(line)
            if match:
                timestamps.append((int(match[1])+1, float(match[2])))
            tail = (tail+[line.strip()])[-6:]
        status = proc.wait()
    if status or not timestamps:
        raise ValueError("未完成取帧，请检查输入格式及时间。"+ " ".join(tail))
    pending = targets.copy()
    with (args.output/"frames.csv").open("x", encoding="utf8", newline="") as out:
        table = csv.writer(out)
        table.writerow(["file","requested_seconds","actual_seconds"])
        for index, actual in timestamps:
            name = f"{index:06d}.jpg"
            if not (args.output/name).is_file():
                raise ValueError(f"缺少解码输出 {name}，请检查解码日志。")
            reached = [t for t in pending if t <= actual+0.00001]
            table.writerow([name,",".join(map(str,reached)),actual])
            pending = pending[len(reached):]
    if pending:
        raise ValueError(f"已保留可用帧，这些时刻之后没有可用画面 {pending}")
    print(f"已保存 {len(timestamps)} 帧，实际时间见 frames.csv")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("video", type=Path)
    parser.add_argument("output", type=Path, help="新建的临时目录")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--step", type=seconds, default=.75)
    group.add_argument("--at", help="按秒选择完整分辨率帧，用逗号分隔")
    parser.add_argument("--range", dest="interval", help="只扫描起秒,止秒")
    args = parser.parse_args()
    if args.at and args.interval:
        parser.error("--range 用于扫描时间段，--at 用于选择特定时刻")
    try:
        extract(args)
    except (OSError, ValueError) as error:
        parser.exit(1, str(error)+"\n")
